/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2013 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "v2fDES.H"
#include "addToRunTimeSelectionTable.H"
#include "wallDist.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{
namespace incompressible
{
namespace LESModels
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(v2fDES, 0);
addToRunTimeSelectionTable(LESModel, v2fDES, dictionary);

// * * * * * * * * * * * * Protected Member Functions  * * * * * * * * * * * //

void v2fDES::updateSubGridScaleFields( const volScalarField& D )
{
       nuSgs_ ==  cmu_*v2_*TDES(D) ;
       nuSgs_.correctBoundaryConditions();
}

tmp<volScalarField> v2fDES::ce1(const volScalarField& k_ , const volScalarField& v2_  ) const
{
   volScalarField k        = max(k_        , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
   volScalarField v2       = max(v2_       , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
//
   tmp<volScalarField> xx = 1.0 + 0.045*sqrt(k/(v2)) ;
   return 1.4*xx ;     
}

volScalarField v2fDES::TDES(  const volScalarField& D ) const
{
      volScalarField k        = max(k_        , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
      volScalarField v2       = max(v2_       , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
      volScalarField epsilon  = max(epsilon_  , dimensionedScalar("0.00001", dimensionSet(0, 2, -3, 0, 0),0.00001 ) ) ;
      volScalarField D1       = max(D         , dimensionedScalar("0.00001", dimensionSet(0, 0, -1, 0, 0),0.00001 ) ) ;


      tmp<volScalarField> Trans = min (
                                     max (  
                                            k/epsilon     , cT_*sqrt(nu()/epsilon)
                                          ) ,
                                     
                                      0.6*k/(sqrt(6.0)*(cmu_*v2*D1 ) ) 
                                   );



      tmp<volScalarField> lmax  = max ( dimensionedScalar("0.0", dimensionSet(0, 0, 0, 0, 0),0.0 )    ,
                                       ((pow(k , 1.5))/epsilon  - cDES_*delta() )/mag( (pow(k , 1.5))/epsilon  - cDES_*delta()   )   
                                      );
      tmp<volScalarField> lmin  = min ( dimensionedScalar("0.0", dimensionSet(0, 0, 0, 0, 0),0.0 )    ,
                                       ((pow(k , 1.5))/epsilon  - cDES_*delta() )/mag( (pow(k , 1.5))/epsilon  - cDES_*delta()   ) 
                                      );

      return  cDES_*delta()/sqrt( k  ) * lmax   - Trans * lmin ; 
      
}

//---------------------------------------------------------------------------------------------------------------------------------------
//
volScalarField v2fDES::LDES( const volScalarField& D ) const
{
      volScalarField k        = max(k_        , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
      volScalarField v2       = max(v2_       , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
      volScalarField epsilon  = max(epsilon_  , dimensionedScalar("0.00001", dimensionSet(0, 2, -3, 0, 0),0.00001 ) ) ;
      volScalarField D1       = max(D         , dimensionedScalar("0.00001", dimensionSet(0, 0, -1, 0, 0),0.00001 ) ) ;

   //tmp<volScalarField> Sm    = mag(symm(gradU));
   tmp<volScalarField> Lrans = max (
                                      min ( 
                                            pow(k , 1.5)/epsilon ,  pow(k , 1.5)/(sqrt(6.0)*(cmu_*v2*D1)) 
                                          ) ,

                                      cEta_ * pow((pow(nu(), 3.0)/epsilon) , 0.25)
                                   )  ;
//
      tmp<volScalarField> lmax  = max ( dimensionedScalar("0.0", dimensionSet(0, 0, 0, 0, 0),0.0 )    ,
                                       ((pow(k , 1.5))/epsilon  - cDES_*delta() )/mag( (pow(k , 1.5))/epsilon  - cDES_*delta()   )
                                      );
      tmp<volScalarField> lmin  = min ( dimensionedScalar("0.0", dimensionSet(0, 0, 0, 0, 0),0.0 )    ,
                                       ((pow(k , 1.5))/epsilon  - cDES_*delta() )/mag( (pow(k , 1.5))/epsilon  - cDES_*delta()   )
                                      );


   return cDES_*delta() * lmax - Lrans * lmin ;
}

//---------------------------------------------------------------------------------------------------------------------------------------

tmp<volScalarField> v2fDES::epsDES(const volScalarField& k_ , const volScalarField& epsilon_  ) const
{
      volScalarField k        = max(k_        , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
      volScalarField v2       = max(v2_       , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
      volScalarField epsilon  = max(epsilon_  , dimensionedScalar("0.00001", dimensionSet(0, 2, -3, 0, 0),0.00001 ) ) ;
//      volScalarField D1       = (D/mag(D))*max(D         , dimensionedScalar("0.00001", dimensionSet(0, 0, -1, 0, 0),0.00001 ) ) ;

      tmp<volScalarField> lmax  = max ( dimensionedScalar("0.0", dimensionSet(0, 0, 0, 0, 0),0.0 )    ,
                                       ((pow(k , 1.5))/epsilon  - cDES_*delta() )/mag( (pow(k , 1.5))/epsilon  - cDES_*delta()   )
                                      );
      tmp<volScalarField> lmin  = min ( dimensionedScalar("0.0", dimensionSet(0, 0, 0, 0, 0),0.0 )    ,
                                       ((pow(k , 1.5))/epsilon  - cDES_*delta() )/mag( (pow(k , 1.5))/epsilon  - cDES_*delta()   )
                                      );

//
   return ( pow(k , 1.5)/(cDES_*delta()) )*lmax - lmin*epsilon_ ;
}

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

v2fDES::v2fDES
(
    const volVectorField& U,
    const surfaceScalarField& phi,
    transportModel& transport,
    const word& turbulenceModelName,
    const word& modelName
)
:
    LESModel(modelName, U, phi, transport, turbulenceModelName),

    ce2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "ce2",
            coeffDict_,
            1.9
        )
    ),
    c1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "c1",
            coeffDict_,
            1.4
        )
    ),
    c2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "c2",
            coeffDict_,
            0.3
        )
    ),
    cL_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cL",
            coeffDict_,
            0.23
        )
    ),
    cDES_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cDES",
            coeffDict_,
            0.80
        )
    ),
    cmu_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cmu",
            coeffDict_,
            0.22
        )
    ),

    sigmaE_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "sigmaE",
            coeffDict_,
            1.3
        )
    ),

    cT_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cT",
            coeffDict_,
            6.0
        )
    ),

    cEta_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cEta",
            coeffDict_,
            70.0
        )
    ),

    k_
    (
        IOobject
        (
            "k",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),

    epsilon_
    (
        IOobject
        (
            "epsilon",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),

    v2_
    (
        IOobject
        (
            "v2",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),

    f_
    (
        IOobject
        (
            "f",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),

    nuSgs_
    (
        IOobject
        (
            "nuSgs",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    )
{
    //omegaMin_.readIfPresent(*this);

    bound(k_, kMin_);
    bound(epsilon_, dimensionedScalar("0.00001", dimensionSet(0, 2, -3, 0, 0),0.00001 ) );
    bound(v2_, dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) );
    bound(f_, dimensionedScalar("0.00001", dimensionSet(0, 0, -1, 0, 0),0.00001 ) );
    //bound(omega_, omegaMin_);

    updateSubGridScaleFields(mag(symm(fvc::grad(U))));

    printCoeffs();
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void v2fDES::correct(const tmp<volTensorField>& gradU)
{
    LESModel::correct(gradU);

    if (mesh_.changing())
    {
        y_.correct();
    }

    volScalarField D =      mag(symm(gradU()));
    volScalarField S2(2.0*magSqr(symm(gradU())));
    volScalarField k        = max(k_        , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
    volScalarField v2       = max(v2_       , dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) ) ;
    gradU.clear();

    epsilon_.boundaryField().updateCoeffs()  ; 
    v2_.boundaryField().updateCoeffs()       ; 
    f_.boundaryField().updateCoeffs()        ; 
    volScalarField P = nuSgs_*S2;       
//
    volScalarField tdes =  TDES (D) ;  
    volScalarField ldes =  cL_*LDES (D) ;  
    volScalarField eps =   epsDES(k_ , epsilon_)  ; 

        tmp<fvScalarMatrix> epsEqn
        (
            fvm::ddt(epsilon_)
          + fvm::div(phi(), epsilon_)
          - fvm::laplacian( DEff(), epsilon_)
          ==
             (ce1(k_ , v2_ )*S2*nuSgs_ )/tdes
          - fvm::Sp(ce2_/tdes, epsilon_)
        );

        epsEqn().relax();
        solve(epsEqn);
        bound(epsilon_, dimensionedScalar("0.00001", dimensionSet(0, 2, -3, 0, 0),0.00001 ) );

    // Turbulent kinetic energy equation
        eps =   epsDES(k_ , epsilon_)  ;
   
        tmp<fvScalarMatrix> kEqn
        (
            fvm::ddt(k_)
          + fvm::div(phi(), k_)
          - fvm::laplacian( DEff(), k_)
        ==
            S2*nuSgs_ - eps
        );

        kEqn().relax();
        solve(kEqn);
        bound(k_, kMin_);
//
        tdes =  TDES (D) ;
        ldes =  cL_*LDES (D) ;
        eps =   epsDES(k_ , epsilon_)  ;

        // f equation
        tmp<fvScalarMatrix> fEqn
        (
            -fvm::laplacian( f_)
        ==
           -fvm::Sp(scalar(1.0)/sqr(ldes) , f_ )  
           -((c1_ - scalar(6.0))*(v2_/k) - (2.0/3.0)*(c1_ - scalar(1.0)))/(sqr(ldes)*tdes)
           +c2_*P/(k*sqr(ldes))
        );

        fEqn().relax();
        solve(fEqn);
        bound(f_, dimensionedScalar("0.00001", dimensionSet(0, 0, -1, 0, 0),0.00001 ) );


     // v2 equation
//        eps =   epsDES(k_ , epsilon_)  ;
      
        tmp<fvScalarMatrix> v2Eqn
        (
            fvm::ddt(v2_)
          + fvm::div(phi(), v2_)
          - fvm::laplacian( DEff(), v2_)
           ==
            min(k_*f_, 5.0*(v2_/k)*eps + (2.0/3.0)*P )
          - fvm::Sp(6.0*eps/k, v2_)      
        );

        v2Eqn().relax();
        solve(v2Eqn);
        bound(v2_, dimensionedScalar("0.00001", dimensionSet(0, 2, -2, 0, 0),0.00001 ) );


   updateSubGridScaleFields(D);
}


/*tmp<volScalarField> v2fDES::epsilon() const
{
    return 2.0*nuEff()*magSqr(symm(fvc::grad(U())));
}
*/

tmp<volSymmTensorField> v2fDES::B() const
{
    return ((2.0/3.0)*I)*k() - nuSgs()*twoSymm(fvc::grad(U()));
}


tmp<volSymmTensorField> v2fDES::devReff() const
{
    return -nuEff()*dev(twoSymm(fvc::grad(U())));
}


tmp<fvVectorMatrix> v2fDES::divDevReff(volVectorField& U) const
{
    return
    (
      - fvm::laplacian(nuEff(), U)
      - fvc::div(nuEff()*dev(T(fvc::grad(U))))
    );
}


tmp<fvVectorMatrix> v2fDES::divDevRhoReff
(
    const volScalarField& rho,
    volVectorField& U
) const
{
    volScalarField muEff("muEff", rho*nuEff());

    return
    (
      - fvm::laplacian(muEff, U)
      - fvc::div(muEff*dev(T(fvc::grad(U))))
    );
}


bool v2fDES::read()
{
    if (LESModel::read())
    {
        ce2_.readIfPresent(coeffDict());

        return true;
    }
    else
    {
        return false;
    }
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace LESModels
} // End namespace incompressible
} // End namespace Foam

// ************************************************************************* //
