/*
	Taylor--Green Vortex initial field
*/
#include "fvCFD.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "setRootCase.H"

    #include "createTime.H"
    #include "createMesh.H"
    #include "createFields.H"

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
    scalar pi = Foam::constant::mathematical::pi;
    vector xi = vector (1.5, 0 ,3.1);   //inizio
    vector xf = vector (2.5, 0, 3.1);   // fine
    scalar r = 0.02;                  // raggio
    scalar e = 25;                    // potenza
    scalar l = mag(xf-xi); 
    scalar d = 0;
    scalar H = 0;
    scalar L1 = 0;
    scalar X1 = 0;
    scalar Y1 = 0;
    scalar L2 = 0;
    scalar X2 = 0;
    scalar Y2 = 0;
    scalar arg1 = 0;
    scalar arg2 = 0;
    scalar arg3 = 0;
    scalar arg4 = 0;
    scalar arg5 = 0;
    scalar arg6 = 0;
    scalar f1 = 0;
    scalar f2 = 0;
    scalar ft = 0;

    forAll(mesh.C(), celli)
    {
       d = Foam::sqrt((sqr(mesh.C()[celli].y()-xi.y())+sqr(mesh.C()[celli].z()-xi.z())));
       H = d/r;


	if (  mesh.C()[celli].x() > xi.x() && mesh.C()[celli].x() < xf.x() )
	      {
                L1 = (mesh.C()[celli].x() - xi.x())/r;
                X1 = sqr(1+H) + sqr(L1);
                Y1 = sqr(1-H) + sqr(L1);
		arg1 = Foam::atan(L1/Foam::sqrt(sqr(H)-1))/L1;
		arg2 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
		arg3 = ((X1-2*H)/Foam::sqrt(X1*Y1))*Foam::atan(Foam::sqrt((X1*(H-1))/(Y1*(H+1))));
                f1 = L1*(arg1-arg2+arg3)/(pi*H);

		L2 = (xf.x()-mesh.C()[celli].x())/r;
                X2 = sqr(1+H) + sqr(L2);
                Y2 = sqr(1-H) + sqr(L2);
                arg4 = Foam::atan(L2/Foam::sqrt(sqr(H)-1))/L2;
                arg5 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
                arg6 = (X2-2*H)/Foam::sqrt(X2*Y2)*Foam::atan(Foam::sqrt((X2*(H-1))/(Y2*(H+1))));
                f2 = L2*(arg4-arg5+arg6)/(pi*H);
		ft = f1+f2;
	       }
	else
	      {
                if ( mesh.C()[celli].x() == xi.x() || mesh.C()[celli].x() == xf.x() )
			{
			L1 = (mesh.C()[celli].x() - xi.x())/r;
                        X1 = sqr(1+H) + sqr(L1);
                        Y1 = sqr(1-H) + sqr(L1);
                        arg1 = Foam::atan(L1/Foam::sqrt(sqr(H)-1))/L1;
                        arg2 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
                        arg3 = (X1-2*H)/Foam::sqrt(X1*Y1)*Foam::atan(Foam::sqrt((X1*(H-1))/(Y1*(H+1))));
                        f1 = L1*(arg1-arg2+arg3)/(pi*H);
			}
		else
		   {
			if (mesh.C()[celli].x() > xf.x())
			    { 
      				L1 = (mesh.C()[celli].x() - xi.x())/r;
     			        X1 = sqr(1+H) + sqr(L1);
                		Y1 = sqr(1-H) + sqr(L1);
                		arg1 = Foam::atan(L1/Foam::sqrt(sqr(H)-1))/L1;
                		arg2 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
                		arg3 = (X1-2*H)/Foam::sqrt(X1*Y1)*Foam::atan(Foam::sqrt((X1*(H-1))/(Y1*(H+1))));
                		f1 = L1*(arg1-arg2+arg3)/(pi*H);

                		L2 = (mesh.C()[celli].x()-xf.x())/r;
                		X2 = sqr(1+H) + sqr(L2);
                		Y2 = sqr(1-H) + sqr(L2);
                		arg4 = Foam::atan(L2/Foam::sqrt(sqr(H)-1))/L2;
                		arg5 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
                		arg6 = (X2-2*H)/Foam::sqrt(X2*Y2)*Foam::atan(Foam::sqrt((X2*(H-1))/(Y2*(H+1))));
                		f2 = L2*(arg4-arg5+arg6)/(pi*H);
                		ft = f1-f2;
			    }
			 else
                            {
                                L1 = (xf.x()-mesh.C()[celli].x())/r;
                                X1 = sqr(1+H) + sqr(L1);
                                Y1 = sqr(1-H) + sqr(L1);
                                arg1 = Foam::atan(L1/Foam::sqrt(sqr(H)-1))/L1;
                                arg2 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
                                arg3 = (X1-2*H)/Foam::sqrt(X1*Y1)*Foam::atan(Foam::sqrt((X1*(H-1))/(Y1*(H+1))));
                                f1 = L1*(arg1-arg2+arg3)/(pi*H);

                                L2 = (xi.x()-mesh.C()[celli].x())/r;
                                X2 = sqr(1+H) + sqr(L2);
                                Y2 = sqr(1-H) + sqr(L2);
                                arg4 = Foam::atan(L2/Foam::sqrt(sqr(H)-1))/L2;
                                arg5 = Foam::atan(Foam::sqrt((H-1)/(H+1)));
                                arg6 = (X2-2*H)/Foam::sqrt(X2*Y2)*Foam::atan(Foam::sqrt((X2*(H-1))/(Y2*(H+1))));
                                f2 = L2*(arg4-arg5+arg6)/(pi*H);
                                ft = f1-f2;
			    }
		   }
	      }
	I[celli]=(e*ft)/(2*pi*r*l);
//	I[celli]=ft;
    }

    I.write();
//    p.write();

    Info<< "end" << endl;

    return 0;
}

// ************************************************************************* //
