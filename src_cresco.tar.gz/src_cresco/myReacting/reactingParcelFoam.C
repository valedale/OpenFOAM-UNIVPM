/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2016 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    reactingParcelFoam

Description
    Transient solver for compressible, turbulent flow with a reacting,
    multiphase particle cloud, and optional sources/constraints.

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "turbulentFluidThermoModel.H"
#include "basicSprayCloud.H"
//#include "basicReactingMultiphaseCloud.H"
#include "rhoCombustionModel.H"
#include "radiationModel.H"
#include "fvOptions.H"
#include "SLGThermo.H"
#include "pimpleControl.H"
#include "localEulerDdtScheme.H"
#include "fvcSmooth.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "postProcess.H"

    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    #include "createControl.H"
    #include "createTimeControls.H"
    #include "createRDeltaT.H"
    #include "createFields.H"
    #include "createFieldRefs.H"
    #include "createFvOptions.H"
    #include "initContinuityErrs.H"

    turbulence->validate();

    if (!LTS)
    {
        #include "compressibleCourantNo.H"
        #include "setInitialDeltaT.H"
    }

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    //dimensionedScalar nAct("nAct",dimensionSet(0,0,0,0,0,0,0), 0.0);   
    Info<< "\nStarting time loop\n" << endl;

    while (runTime.run())
    {
        #include "readTimeControls.H"

        if (!LTS)
        {
            #include "compressibleCourantNo.H"
            #include "setDeltaT.H"
        }

        runTime++;

        Info<< "Time = " << runTime.timeName() << nl << endl;

        parcels.evolve();

        if (LTS)
        {
            #include "setRDeltaT.H"
        }

        #include "rhoEqn.H"

        // --- Pressure-velocity PIMPLE corrector loop
        while (pimple.loop())
        {
            #include "UEqn.H"
            #include "YEqn.H"
            #include "EEqn.H"

            // --- Pressure corrector loop
            while (pimple.correct())
            {
                #include "pEqn.H"
            }

            if (pimple.turbCorr())
            {
                turbulence->correct();
            }
        }

        rho = thermo.rho();

        runTime.write();

        scalar d10 = 1.0e+6*parcels.Dij(1, 0);
        Info<<   "D10 = " << d10 << nl << endl;

        scalar lpl = parcels.LPL(0.95);
        Info<<   "LPL = " << lpl << nl << endl;
        scalar lpl2 = parcels.LPL2(0.95);
        Info<<   "LPL2 = " << lpl2 << nl << endl;

        scalar lpl80 = parcels.LPL(0.80);
        Info<<   "LPL80 = " << lpl80 << nl << endl;

        scalar lpl60 = parcels.LPL(0.60);
        Info<<   "LPL60 = " << lpl60 << nl << endl;

        scalar xg = parcels.xg();
        Info<<   "xg = " << xg << nl << endl;
        scalar yg = parcels.yg();
        Info<<   "yg = " << yg << nl << endl;
        scalar zg = parcels.zg();
        Info<<   "zg = " << zg << nl << endl;

                               //xmax  zmax   zmin
        scalar RV1 = parcels.RV( 1.0 , 1.8 ,  1.3);
        Info<<   "1m-RI = " << RV1 << nl << endl;
        scalar RV2 = parcels.RV( 0.5 , 1.8 ,  1.3);
        Info<<   "0.5m-RI = " << RV2 << nl << endl;

                                  //xmax  zmax   zmin
        scalar RV1a = parcels.RVact( 1.0 , 1.8 ,  1.3);
        Info<<   "1m-RIa = " << RV1a << nl << endl;
        scalar RV2a = parcels.RVact( 0.5 , 1.8 ,  1.3);
        Info<<   "0.5m-RIa = " << RV2a << nl << endl;
        scalar af = parcels.AF();
        Info<<   "Active Fraction = " << af << nl << endl;
        
        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
